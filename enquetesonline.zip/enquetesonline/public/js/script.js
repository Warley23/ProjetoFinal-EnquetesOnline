document.addEventListener('DOMContentLoaded', function () {

    document.getElementById('addQuestionButton').addEventListener('click', function() {
        const questionsContainer = document.getElementById('questionsContainer');
        const existingQuestions = questionsContainer.getElementsByClassName('question-item').length;
        const questionNumber = existingQuestions + 1;

        const newQuestionDiv = document.createElement('div');
        newQuestionDiv.classList.add('form-group', 'question-item');
        newQuestionDiv.innerHTML = `
            <label for="question${questionNumber}">Pergunta ${questionNumber}</label>
            <input type="text" class="form-control" id="question${questionNumber}" name="questions[]" required>
            <button type="button" class="btn btn-danger btn-sm remove-question" onclick="removeQuestion(this)">Remover</button>
        `;

        questionsContainer.appendChild(newQuestionDiv);
    });
});

function removeQuestion(button) {
    const questionItem = button.closest('.question-item');
    questionItem.remove();
    updateQuestionNumbers();
}

function updateQuestionNumbers() {
    const questions = document.querySelectorAll('.question-item');
    questions.forEach((question, index) => {
        const label = question.querySelector('label');
        label.textContent = `Pergunta ${index + 1}`;
        const input = question.querySelector('input');
        input.id = `question${index + 1}`;
        input.setAttribute('name', `questions[${index}]`);
    });
}

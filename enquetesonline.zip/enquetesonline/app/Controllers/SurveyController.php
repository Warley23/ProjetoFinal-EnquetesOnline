<?php namespace App\Controllers;

use App\Models\SurveyModel;
use App\Models\ResponseModel;

class SurveyController extends BaseController
{
    public function create()
    {
        $model = new SurveyModel();

        if ($this->request->getMethod() === 'post') {
            $title = $this->request->getPost('title');
            $description = $this->request->getPost('description');
            $questions = $this->request->getPost('questions');

            $surveyId = $model->saveSurvey([
                'title' => $title,
                'description' => $description
            ]);

            if ($surveyId) {
                $model->saveQuestions($surveyId, $questions);
                return redirect()->to('/survey/success'); // Redireciona para uma página de sucesso
            }
        }

        // Carrega a view para criar uma enquete
        return view('criar_enquete');
    }
    public function success()
    {
        // Exibir a view de sucesso
        return view('survey_success');
    }

    public function verEnquetes()
    {
        $model = new SurveyModel();
        $data['enquetes'] = $model->getSurveysWithQuestions();
    
        return view('ver_enquetes', $data);
    }
    public function responderEnquete($surveyId)
{
    $model = new SurveyModel();
    $data['enquete'] = $model->getSurveyById($surveyId);

    return view('responder_enquete', $data);
}

public function submitEnqueteResposta()
{
    $surveyId = $this->request->getPost('survey_id');
    $responses = $this->request->getPost('responses');
    $responseModel = new ResponseModel();
    $surveyModel = new SurveyModel(); // Usando SurveyModel para verificar as perguntas

    foreach ($responses as $questionId => $responseText) {
        if (!empty($responseText)) {
            // Verifique se a pergunta existe dentro da enquete específica
            if ($surveyModel->questionExistsInSurvey($questionId, $surveyId)) {
                $data = [
                    'survey_id' => $surveyId,
                    'question_id' => $questionId,
                    'response_text' => $responseText
                ];
                $responseModel->save($data);
            } else {
                // Tratar o caso de a pergunta não existir
                // Opção: Adicionar alguma lógica de erro aqui
            }
        }
    }

    return redirect()->to('/survey/response-success'); // Redireciona para a página de sucesso
}

public function responseSuccess()
{
    return view('survey_response_success');
}
public function editarEnquete($surveyId)
{
    $model = new SurveyModel();

    // Buscar os dados da enquete
    $enquete = $model->getSurveyById($surveyId);
    
    if (!$enquete) {
        // Tratar caso a enquete não seja encontrada
        return redirect()->to('/ver-enquetes');
    }

    // Exibir a view de edição com os dados da enquete
    return view('editar_enquete', ['enquete' => $enquete]);
}

public function salvarEdicaoEnquete()
{
    $model = new SurveyModel();
    $surveyId = $this->request->getPost('id');
    $title = $this->request->getPost('title');
    $description = $this->request->getPost('description');
    $existingQuestions = $this->request->getPost('questions');
    $newQuestions = $this->request->getPost('new_questions');
    $removedQuestions = $this->request->getPost('removed_questions');

    // Atualiza a enquete
    $model->update($surveyId, [
        'title' => $title,
        'description' => $description
    ]);

    // Atualiza as perguntas existentes
    if ($existingQuestions) {
        foreach ($existingQuestions as $questionId => $questionText) {
            $model->updateQuestion($questionId, $questionText);
        }
    }

    // Adiciona novas perguntas
    if ($newQuestions) {
        foreach ($newQuestions as $questionText) {
            if (!empty($questionText)) {
                $model->addQuestion($surveyId, $questionText);
            }
        }
    }

    // Remove as perguntas selecionadas
    if ($removedQuestions) {
        foreach ($removedQuestions as $questionId) {
            $model->removeQuestion($questionId);
        }
    }

    return redirect()->to('/ver-enquetes')->with('success', 'Enquete atualizada com sucesso.');
}



    public function excluirEnquete($surveyId)
    {
        $model = new SurveyModel();
    
        if ($model->find($surveyId)) {
            // Primeiro, exclui todas as respostas relacionadas às perguntas da enquete
            $model->deleteResponsesBySurvey($surveyId);
    
            // Em seguida, exclui todas as perguntas da enquete
            $model->deleteQuestions($surveyId);
    
            // Por fim, exclui a enquete
            $model->delete($surveyId);
    
            return redirect()->to('/ver-enquetes')->with('success', 'Enquete excluída com sucesso.');
        } else {
            return redirect()->to('/ver-enquetes')->with('error', 'Enquete não encontrada.');
        }
    }
    
    

}



<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('enquete_page');
    }

    public function criarEnquete(): string
    {
        return view('criar_enquete');
    }
}

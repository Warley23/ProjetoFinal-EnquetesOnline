<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('criar-enquete', 'Home::criarEnquete');
$routes->get('criar-enquete', 'SurveyController::create');
$routes->post('criar-enquete', 'SurveyController::create');
$routes->get('survey/success', 'SurveyController::success');
$routes->get('ver-enquetes', 'SurveyController::verEnquetes');
$routes->get('responder-enquete/(:num)', 'SurveyController::responderEnquete/$1');
$routes->post('submit-enquete-resposta', 'SurveyController::submitEnqueteResposta');
$routes->get('survey/response-success', 'SurveyController::responseSuccess');
$routes->get('editar-enquete/(:num)', 'SurveyController::editarEnquete/$1');
$routes->get('excluir-enquete/(:num)', 'SurveyController::excluirEnquete/$1');
$routes->post('salvar-edicao-enquete', 'SurveyController::salvarEdicaoEnquete');


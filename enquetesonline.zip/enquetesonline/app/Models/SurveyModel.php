<?php namespace App\Models;

use CodeIgniter\Model;

class SurveyModel extends Model
{
    protected $table = 'surveys';
    protected $allowedFields = ['title', 'description'];

    public function saveSurvey($data)
    {
        return $this->insert($data);
    }

    public function saveQuestions($surveyId, $questions)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('questions');

        foreach ($questions as $question) {
            $builder->insert([
                'survey_id' => $surveyId,
                'question_text' => $question
            ]);
        }
    }
    public function getSurveysWithQuestions()
    {
        $this->select('surveys.*, questions.question_text');
        $this->join('questions', 'questions.survey_id = surveys.id', 'left');
        $this->orderBy('surveys.created_at', 'desc');
        $surveys = $this->findAll();

        $organizedSurveys = [];
        foreach ($surveys as $survey) {
            $surveyId = $survey['id'];
            if (!isset($organizedSurveys[$surveyId])) {
                $organizedSurveys[$surveyId] = [
                    'id' => $surveyId,
                    'title' => $survey['title'],
                    'description' => $survey['description'],
                    'questions' => []
                ];
            }
            if (!empty($survey['question_text'])) {
                $organizedSurveys[$surveyId]['questions'][] = $survey['question_text'];
            }
        }

        return array_values($organizedSurveys);
    }
    public function getSurveyById($surveyId)
{
    $this->select('surveys.id, surveys.title, surveys.description, questions.question_text');
    $this->join('questions', 'questions.survey_id = surveys.id', 'left');
    $this->where('surveys.id', $surveyId);
    $query = $this->get();

    $surveyData = $query->getRowArray();
    if (!$surveyData) {
        return null;
    }

    $surveyData['questions'] = $query->getResultArray();
    return $surveyData;
}

public function updateQuestion($questionId, $questionText)
{
    $db = \Config\Database::connect();
    $builder = $db->table('questions');
    $builder->where('id', $questionId);
    $builder->update(['question_text' => $questionText]);
}

public function saveQuestion($surveyId, $data)
{
    $data['survey_id'] = $surveyId;
    $builder = $this->db->table('questions');
    $builder->insert($data);
}
public function salvarEdicaoEnquete()
{
    $model = new SurveyModel();
    $surveyId = $this->request->getPost('id');
    $data = [
        'title' => $this->request->getPost('title'),
        'description' => $this->request->getPost('description')
        // Adicione outros campos conforme necessário
    ];

    $model->update($surveyId, $data);

    // Redirecionar para a página de listagem de enquetes com uma mensagem de sucesso
    return redirect()->to('/ver-enquetes')->with('success', 'Enquete atualizada com sucesso.');
}
public function deleteQuestions($surveyId)
{
    $db = \Config\Database::connect();
    $builder = $db->table('questions');
    $builder->where('survey_id', $surveyId);
    $builder->delete();
}
public function deleteResponsesBySurvey($surveyId)
{
    $db = \Config\Database::connect();
    $builder = $db->table('responses');

    // Primeiro, obtenha todos os IDs das perguntas da enquete especificada
    $questionIds = $db->table('questions')
                      ->select('id')
                      ->where('survey_id', $surveyId)
                      ->get()
                      ->getResultArray();

    // Se houver perguntas, exclua as respostas relacionadas
    if (!empty($questionIds)) {
        $questionIds = array_column($questionIds, 'id');
        $builder->whereIn('question_id', $questionIds);
        $builder->delete();
    }
}
public function questionExistsInSurvey($questionId, $surveyId)
{
    // Assumindo que você tem uma tabela de perguntas chamada 'questions'
    // e que ela tem colunas 'id' para o ID da pergunta e 'survey_id' para o ID da enquete
    $db = \Config\Database::connect();
    $builder = $db->table('questions');

    $query = $builder->getWhere(['id' => $questionId, 'survey_id' => $surveyId]);
    return $query->getRowArray() !== null;
}

}

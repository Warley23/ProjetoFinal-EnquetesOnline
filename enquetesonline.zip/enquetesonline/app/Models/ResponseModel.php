<?php namespace App\Models;

use CodeIgniter\Model;

class ResponseModel extends Model
{
    protected $table = 'responses';
    protected $allowedFields = ['question_id', 'response_text'];

    public function saveResponses($responses)
    {
        foreach ($responses as $questionId => $responseText) {
            $data = [
                'question_id' => $questionId,
                'response_text' => $responseText
            ];
            $this->insert($data);
        }
    }
}

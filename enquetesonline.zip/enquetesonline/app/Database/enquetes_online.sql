-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 20-Jan-2024 às 00:45
-- Versão do servidor: 10.4.28-MariaDB
-- versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `enquetes_online`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `survey_id` int(11) DEFAULT NULL,
  `question_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `questions`
--

INSERT INTO `questions` (`id`, `survey_id`, `question_text`, `created_at`) VALUES
(20, 3, 'Qual é o propósito de uma variável em programação?', '2024-01-19 23:39:59'),
(21, 3, 'Explique a diferença entre linguagens de programação compiladas e interpretadas.', '2024-01-19 23:39:59'),
(22, 3, 'O que são algoritmos e por que são importantes na programação?', '2024-01-19 23:39:59'),
(23, 4, 'O que é uma classe em programação orientada a objetos?', '2024-01-19 23:40:56'),
(24, 4, 'Como a herança é usada na programação orientada a objetos?', '2024-01-19 23:40:56'),
(25, 4, 'O que são e como funcionam os métodos em uma classe?', '2024-01-19 23:40:56'),
(26, 5, 'Qual é a diferença entre HTML e CSS?', '2024-01-19 23:42:16'),
(27, 5, 'O que é JavaScript e para que é mais comumente usado?', '2024-01-19 23:42:16'),
(28, 5, 'Explique o conceito de \'resposta do servidor\' em um contexto de desenvolvimento web.', '2024-01-19 23:42:16'),
(29, 6, 'O que é um banco de dados relacional?', '2024-01-19 23:43:28'),
(30, 6, 'Descreva o que é SQL e para que é utilizado.', '2024-01-19 23:43:28'),
(31, 6, 'Explique a diferença entre SQL e NoSQL.', '2024-01-19 23:43:28'),
(32, 7, 'O que é programação funcional e como ela difere da programação imperativa?', '2024-01-19 23:44:31'),
(33, 7, 'Explique o conceito de \'computação em nuvem\'.', '2024-01-19 23:44:31'),
(34, 7, 'Qual é a importância da inteligência artificial e do aprendizado de máquina na programação moderna?', '2024-01-19 23:44:31');

-- --------------------------------------------------------

--
-- Estrutura da tabela `responses`
--

CREATE TABLE `responses` (
  `id` int(11) NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `response_text` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `surveys`
--

CREATE TABLE `surveys` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `surveys`
--

INSERT INTO `surveys` (`id`, `title`, `description`, `created_at`) VALUES
(3, 'Fundamentos de Programação', 'Compreendendo os Fundamentos da Programação', '2024-01-19 23:39:59'),
(4, 'Programação Orientada a Objetos', 'Conceitos Básicos de Programação Orientada a Objetos', '2024-01-19 23:40:56'),
(5, 'Desenvolvimento Web', 'Fundamentos do Desenvolvimento Web', '2024-01-19 23:42:16'),
(6, 'Bancos de Dados', 'Básico sobre Bancos de Dados', '2024-01-19 23:43:28'),
(7, ' Tendências em Programação', 'Tendências Atuais em Tecnologia e Programação', '2024-01-19 23:44:31');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `survey_id` (`survey_id`);

--
-- Índices para tabela `responses`
--
ALTER TABLE `responses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`);

--
-- Índices para tabela `surveys`
--
ALTER TABLE `surveys`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT de tabela `responses`
--
ALTER TABLE `responses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `surveys`
--
ALTER TABLE `surveys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`);

--
-- Limitadores para a tabela `responses`
--
ALTER TABLE `responses`
  ADD CONSTRAINT `responses_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

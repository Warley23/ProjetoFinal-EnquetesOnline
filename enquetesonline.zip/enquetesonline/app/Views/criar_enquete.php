<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sistema de Enquetes Online - Obtenha feedback instantâneo e faça decisões inteligentes">
    <title>Sistema de Enquetes Online</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
    <header>
        <nav aria-label="Menu principal">
            <div class="logo">
                <img src="<?= base_url('img/logo.png') ?>" alt="Logo EnquetesOnline">
                EnquetesOnline
            </div>
            <ul>
                <li><a href="http://localhost/enquetesonline/public/#">Início</a></li>
                <li><a href="http://localhost/enquetesonline/public/criar-enquete">Criar Enquete</a></li>
                <li><a href="#">Ver Enquetes</a></li>
                <li><a href="#">Sobre</a></li>
            </ul>
        </nav>
    </header>
    <div class="container mt-5">
        <h2 class="mb-4">Criar Nova Enquete</h2>
        <form action="<?= base_url('criar-enquete') ?>" method="post" id="surveyForm">
            <div class="form-group">
                <label for="surveyTitle">Título da Enquete</label>
                <input type="text" class="form-control" id="surveyTitle" name="title" required>
            </div>

            <div class="form-group">
                <label for="surveyDescription">Descrição</label>
                <textarea class="form-control" id="surveyDescription" name="description" rows="3"></textarea>
            </div>

            <div id="questionsContainer">
    <div class="form-group question-item">
        <label for="question1">Pergunta 1</label>
        <input type="text" class="form-control" id="question1" name="questions[]" required>
        <button type="button" class="btn btn-danger btn-sm remove-question" onclick="removeQuestion(this)">Remover</button>
    </div>
</div>
            <button type="button" class="btn btn-secondary mb-3" id="addQuestionButton">Adicionar Pergunta</button>
            <button type="submit" class="btn btn-primary">Criar Enquete</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="<?= base_url('js/script.js') ?>"></script>
</body>
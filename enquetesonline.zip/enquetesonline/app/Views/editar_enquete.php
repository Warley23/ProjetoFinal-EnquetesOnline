<!DOCTYPE html>
<html lang="pt-br">
<head>
    <!-- Metatags e links para CSS -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sistema de Enquetes Online - Obtenha feedback instantâneo e faça decisões inteligentes">
    <title>Sistema de Enquetes Online</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        .question-item {
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            position: relative;
        }
        .remove-question {
            position: absolute;
            top: 10px;
            right: 10px;
        }
    </style>
</head>
<body>
    <!-- Navbar aqui -->
    <header>
        <nav aria-label="Menu principal">
            <div class="logo">
                <img src="<?= base_url('img/logo.png') ?>" alt="Logo EnquetesOnline">
                EnquetesOnline
            </div>
            <ul>
                <li><a href="http://localhost/enquetesonline/public/#">Início</a></li>
                <li><a href="http://localhost/enquetesonline/public/criar-enquete">Criar Enquete</a></li>
                <li><a href="http://localhost/enquetesonline/public/ver-enquetes">Ver Enquetes</a></li>
                <li><a href="#">Sobre</a></li>
            </ul>
        </nav>
    </header>
    <div class="container mt-5">
        <h2>Editando Enquete: <?= esc($enquete['title']) ?></h2>
        <form action="<?= base_url('salvar-edicao-enquete') ?>" method="post">
            <input type="hidden" name="id" value="<?= esc($enquete['id']) ?>">
            
            <div class="form-group">
                <label>Título</label>
                <input type="text" class="form-control" name="title" value="<?= esc($enquete['title']) ?>">
            </div>
            
            <div class="form-group">
                <label>Descrição</label>
                <textarea class="form-control" name="description"><?= esc($enquete['description']) ?></textarea>
            </div>

            <h4>Perguntas</h4>
<div id="questionsContainer">
    <?php foreach ($enquete['questions'] as $question): ?>
        <div class="form-group question-item">
            <label>Pergunta</label>
            <input type="text" class="form-control" name="questions[<?= $question['id'] ?>]" value="<?= esc($question['question_text']) ?>">
            <button type="button" class="btn btn-danger btn-sm remove-question" data-question-id="<?= $question['id'] ?>">Remover</button>
        </div>
    <?php endforeach; ?>
</div>

<button type="button" class="btn btn-secondary" id="addQuestionButton">Adicionar Pergunta</button>
<button type="submit" class="btn btn-primary">Salvar Alterações</button>

        </form>
    </div>

    <!-- Scripts JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script>
    document.getElementById('addQuestionButton').addEventListener('click', function() {
        const questionsContainer = document.getElementById('questionsContainer');
        const newQuestionDiv = document.createElement('div');
        newQuestionDiv.classList.add('form-group', 'question-item');
        newQuestionDiv.innerHTML = `
            <label>Nova Pergunta</label>
            <input type="text" class="form-control" name="new_questions[]">
        `;
        questionsContainer.appendChild(newQuestionDiv);
    });

    document.getElementById('questionsContainer').addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('remove-question')) {
            if (e.target.getAttribute('data-question-id')) {
                // Se a pergunta é existente, adicione um input oculto para marcá-la como removida
                const removedQuestionInput = document.createElement('input');
                removedQuestionInput.type = 'hidden';
                removedQuestionInput.name = 'removed_questions[]';
                removedQuestionInput.value = e.target.getAttribute('data-question-id');
                document.forms[0].appendChild(removedQuestionInput);
            }
            e.target.closest('.question-item').remove();
        }
    });
</script>

</body>
</html>

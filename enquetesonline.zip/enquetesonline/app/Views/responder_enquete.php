<!DOCTYPE html>
<html lang="pt-br">
<head>
    <!-- Metatags e links para CSS -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sistema de Enquetes Online - Obtenha feedback instantâneo e faça decisões inteligentes">
    <title>Sistema de Enquetes Online</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
    <!-- NavBar aqui -->
    <header>
        <nav aria-label="Menu principal">
            <div class="logo">
                <img src="<?= base_url('img/logo.png') ?>" alt="Logo EnquetesOnline">
                EnquetesOnline
            </div>
            <ul>
                <li><a href="http://localhost/enquetesonline/public/#">Início</a></li>
                <li><a href="http://localhost/enquetesonline/public/criar-enquete">Criar Enquete</a></li>
                <li><a href="http://localhost/enquetesonline/public/ver-enquetes">Ver Enquetes</a></li>
                <li><a href="#">Sobre</a></li>
            </ul>
        </nav>
    </header>
    <div class="container mt-5">
        <h2><?= esc($enquete['title']) ?></h2>
        <p><?= esc($enquete['description']) ?></p>
        
        <form action="<?= base_url('submit-enquete-resposta') ?>" method="post">
            <input type="hidden" name="survey_id" value="<?= esc($enquete['id']) ?>">
            
            <?php foreach ($enquete['questions'] as $question): ?>
    <div class="form-group">
        <label><?= esc($question['question_text']) ?></label>
        <input type="text" class="form-control" name="responses[<?= $question['id'] ?>]" required>
    </div>
<?php endforeach; ?>


            <button type="submit" class="btn btn-primary">Enviar Respostas</button>
        </form>
    </div>

    <!-- Scripts JS -->
    <script src="script.js"></script>
</body>
</html>

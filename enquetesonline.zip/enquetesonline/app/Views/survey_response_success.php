<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resposta Enviada - Sistema de Enquetes Online</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="jumbotron">
            <h1 class="display-4">Obrigado!</h1>
            <p class="lead">Sua resposta foi enviada com sucesso.</p>
            <hr class="my-4">
            <p>Quer ver outras enquetes ou voltar para a página inicial?</p>
            <a class="btn btn-primary btn-lg" href="<?= base_url('/') ?>" role="button">Página Inicial</a>
            <a class="btn btn-secondary btn-lg" href="<?= base_url('ver-enquetes') ?>" role="button">Ver Enquetes</a>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>

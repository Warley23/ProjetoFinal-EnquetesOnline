<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sistema de Enquetes Online - Obtenha feedback instantâneo e faça decisões inteligentes">
    <title>Sistema de Enquetes Online</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
    <header>
        <nav aria-label="Menu principal">
            <div class="logo">
                <img src="<?= base_url('img/logo.png') ?>" alt="Logo EnquetesOnline">
                EnquetesOnline
            </div>
            <ul>
                <li><a href="http://localhost/enquetesonline/public/#">Início</a></li>
                <li><a href="http://localhost/enquetesonline/public/criar-enquete">Criar Enquete</a></li>
                <li><a href="http://localhost/enquetesonline/public/ver-enquetes">Ver Enquetes</a></li>
                <li><a href="#">Sobre</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="hero" aria-label="Introdução">
            <div class="hero-content">
                <h1>Feedback Instantâneo, Decisões Inteligentes</h1>
                <p>"Crie enquetes facilmente e obtenha insights valiosos para tomar decisões mais informadas."</p>
                <a href="http://localhost/enquetesonline/public/criar-enquete" class="btn-primary">Comece Agora</a>
            </div>
        </section>

        <section class="portfolio-section" aria-label="Portfólio">
            <div class="container2">
                <h2 class="text-center mt-5 mb-4">Nossas Soluções</h2>
                <div class="row">
                    <!-- Cards do Portfólio -->
                    <!-- Card 1: Criação de Enquetes Simples -->
                    <div class="col-md-4 mb-4">
                            <div class="card text-center">
                                <div class="card-body">
                                    <i class="bi bi-pencil-square" style="font-size: 2rem;"></i>
                                    <h5 class="card-title mt-3">Criação Simples de Enquetes</h5>
                                    <p class="card-text">Ferramenta intuitiva para criar enquetes online rapidamente.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Card 2: Coleta de Feedback -->
                        <div class="col-md-4 mb-4">
                            <div class="card text-center">
                                <div class="card-body">
                                    <i class="bi bi-chat-right-dots" style="font-size: 2rem;"></i>
                                    <h5 class="card-title mt-3">Coleta de Feedback</h5>
                                    <p class="card-text">Ideal para coletar opiniões, sugestões e feedback valioso.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Card 3: Realização de Pesquisas Simples -->
                        <div class="col-md-4 mb-4">
                            <div class="card text-center">
                                <div class="card-body">
                                    <i class="bi bi-graph-up" style="font-size: 2rem;"></i>
                                    <h5 class="card-title mt-3">Pesquisas Simples</h5>
                                    <p class="card-text">Ferramentas eficazes para realizar pesquisas e análises simples.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Sistema de Enquetes Online. Todos os direitos reservados.</p>
    </footer>

    <script src="script.js"></script>
</body>
</html>

                        
 
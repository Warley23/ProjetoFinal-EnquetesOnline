<!DOCTYPE html>
<html lang="pt-br">
<head>
    <!-- Seus cabeçalhos existentes aqui -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sistema de Enquetes Online - Obtenha feedback instantâneo e faça decisões inteligentes">
    <title>Sistema de Enquetes Online</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
    <!-- Seu código de NavBar aqui -->
    <header>
        <nav aria-label="Menu principal">
            <div class="logo">
                <img src="<?= base_url('img/logo.png') ?>" alt="Logo EnquetesOnline">
                EnquetesOnline
            </div>
            <ul>
                <li><a href="http://localhost/enquetesonline/public/#">Início</a></li>
                <li><a href="http://localhost/enquetesonline/public/criar-enquete">Criar Enquete</a></li>
                <li><a href="#">Ver Enquetes</a></li>
                <li><a href="#">Sobre</a></li>
            </ul>
        </nav>
    </header>
    <div class="container mt-5">
        <div class="alert alert-success" role="alert">
            Enquete criada com sucesso!
        </div>
        <a href="<?= base_url('ver-enquetes') ?>" class="btn btn-primary">Ver Enquetes</a>
    </div>

    <!-- Seus scripts existentes aqui -->
    
    <script src="script.js"></script>
</body>
</html>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <!-- Seus cabeçalhos existentes aqui -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Sistema de Enquetes Online - Obtenha feedback instantâneo e faça decisões inteligentes">
    <title>Sistema de Enquetes Online</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('css/style.css') ?>">
</head>
<body>
    <!-- Seu código de NavBar aqui -->
    <header>
        <nav aria-label="Menu principal">
            <div class="logo">
                <img src="<?= base_url('img/logo.png') ?>" alt="Logo EnquetesOnline">
                EnquetesOnline
            </div>
            <ul>
                <li><a href="http://localhost/enquetesonline/public/#">Início</a></li>
                <li><a href="http://localhost/enquetesonline/public/criar-enquete">Criar Enquete</a></li>
                <li><a href="http://localhost/enquetesonline/public/ver-enquetes">Ver Enquetes</a></li>
                <li><a href="#">Sobre</a></li>
            </ul>
        </nav>
    </header>
    <div class="container mt-5">
        <h2>Enquetes Disponíveis</h2>
        <div class="list-group">
        <div class="list-group">
    <?php foreach ($enquetes as $enquete): ?>
        <div class="list-group-item">
            <h5 class="mb-1"><?= esc($enquete['title']) ?></h5>
            <p class="mb-1"><?= esc($enquete['description']) ?></p>
            <div class="btn-group" role="group">
                <a href="<?= base_url('responder-enquete/' . $enquete['id']) ?>" class="btn btn-primary btn-sm">Responder</a>
                <a href="<?= base_url('editar-enquete/' . $enquete['id']) ?>" class="btn btn-secondary btn-sm">Editar</a>
                <a href="<?= base_url('excluir-enquete/' . $enquete['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir esta enquete?');">Excluir</a>
            </div>
        </div>
    <?php endforeach; ?>
</div>

        </div>
    </div>

    <!-- Seus scripts existentes aqui -->
    <script src="script.js"></script>
</body>
</html>
